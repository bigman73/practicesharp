using System;
using System.Collections.Generic;
using System.Text;

namespace NAudio.Wave.Compression
{
    enum AcmStreamSizeFlags
    {
        /// <summary>
        /// ACM_STREAMSIZEF_SOURCE
        /// </summary>
        Source = 0x00000000,
        /// <summary>
        /// ACM_STREAMSIZEF_DESTINATION
        /// </summary>
        Destination = 0x00000001
    }
}
